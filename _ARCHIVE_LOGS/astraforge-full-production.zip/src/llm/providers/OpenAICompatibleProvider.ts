import OpenAI from 'openai';
import * as math from 'mathjs';

interface Config {
  apiKey: string;
  baseURL?: string;
  model: string;
}

export interface GenerateResponse {
  text: string;
  confidence: number;
}

export interface Embedding {
  embedding: number[];
}

export class OpenAICompatibleProvider {
  private client: OpenAI;
  private config: Config;

  constructor(config: Config) {
    this.config = config;
    this.client = new OpenAI({
      apiKey: config.apiKey,
      baseURL: config.baseURL,
    });
  }

  async generate(prompt: string): Promise<GenerateResponse> {
    try {
      const completion = await this.client.chat.completions.create({
        model: this.config.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 1024,
        temperature: 0.7,
      });

      const text = completion.choices[0]?.message?.content || '';
      const confidence = completion.choices[0]?.finish_reason === 'stop' ? 0.8 : 0.5;

      return { text, confidence };
    } catch (error) {
      console.error('OpenAICompatible generate error:', error);
      throw error;
    }
  }

  async embed(text: string): Promise<number[]> {
    try {
      const embeddingResponse = await this.client.embeddings.create({
        model: 'text-embedding-3-small',
        input: text,
      });
      return embeddingResponse.data[0].embedding || [];
    } catch (error) {
      console.error('OpenAICompatible embed error:', error);
      throw error;
    }
  }

  static createForOne(apiKey: string): OpenAICompatibleProvider {
    return new OpenAICompatibleProvider({
      apiKey,
      model: 'gpt-4o-mini',
    });
  }

  static createForThree(apiKey: string): OpenAICompatibleProvider {
    return new OpenAICompatibleProvider({
      apiKey,
      baseURL: 'https://api.x.ai/v1',
      model: 'grok-beta',
    });
  }

  static createForFour(apiKey: string): OpenAICompatibleProvider {
    return new OpenAICompatibleProvider({
      apiKey,
      baseURL: 'https://openrouter.ai/api/v1',
      model: 'openai/gpt-4o-mini',
    });
  }
}
EOF && cat src/llm/providers/AnthropicProvider.ts
