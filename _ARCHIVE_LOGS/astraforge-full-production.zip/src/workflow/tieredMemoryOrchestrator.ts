// Add addDocument to VectorDB class in vectorDB.ts already done
