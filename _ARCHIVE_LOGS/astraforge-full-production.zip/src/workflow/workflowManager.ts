export class WorkflowManager {
  // Impl from Phase 3
  async runWorkflow(spec: string): Promise<string> {
    return 'workflow result';
  }
}
