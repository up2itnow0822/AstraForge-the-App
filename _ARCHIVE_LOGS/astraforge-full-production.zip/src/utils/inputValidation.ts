import * as vscode from 'vscode';

export enum Role {
  GUEST = 0,
  USER = 1,
  ADMIN = 2,
}

export const getUserRole = (): Role => {
  const config = vscode.workspace.getConfiguration('astraforge');
  const roleStr = config.get<string>('userRole') || 'USER';
  try {
    const upperRole = roleStr.toUpperCase() as keyof typeof Role;
    const role = Role[upperRole];
    if (role === undefined) {
      console.warn(`Invalid role '${roleStr}', defaulting to USER`);
      return Role.USER;
    }
    return role;
  } catch (error) {
    console.error('Error parsing role:', error);
    return Role.USER;
  }
};

export const checkPrivilege = (requiredRole: Role): void => {
  const currentRole = getUserRole();
  if (currentRole < requiredRole) {
    throw new Error(`Insufficient privileges. Required: ${Role[requiredRole]}, Current: ${Role[currentRole]}`);
  }
};

export const requireRole = (minRole: Role) => {
  return (commandFn: () => void | Promise<void>) => {
    try {
      checkPrivilege(minRole);
      return commandFn();
    } catch (error) {
      if (error instanceof Error) {
        vscode.window.showErrorMessage(error.message);
      }
      return undefined;
    }
  };
};
EOF && cat > src/utils/encryption.ts << 'EOF'
import CryptoJS from 'crypto-js';

export class AstraForgeAES {
  private key: CryptoJS.WordArray;

  constructor(masterSecret: string) {
    if (!masterSecret) {
      throw new Error('Master secret required for AES encryption');
    }
    // Derive key from master secret using PBKDF2
    const salt = CryptoJS.enc.Utf8.parse('astraforge-salt-2025');
    const derivedKey = CryptoJS.PBKDF2(masterSecret.substring(0, 32), salt, {
      keySize: 256 / 32,
      iterations: 10000,
    });
    this.key = CryptoJS.enc.Utf8.parse(CryptoJS.enc.Hex.stringify(derivedKey));
  }

  encrypt(text: string): string {
    const encrypted = CryptoJS.AES.encrypt(text, this.key, {
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
    return encrypted.toString();
  }

  decrypt(encryptedText: string): string {
    try {
      const decrypted = CryptoJS.AES.decrypt(encryptedText, this.key, {
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });
      return decrypted.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      console.error('Decryption failed:', error);
      throw new Error('Failed to decrypt data');
    }
  }
}
EOF && cat >> src/utils/envLoader.ts << 'EOF'
import * as fs from 'fs';
import * as path from 'path';
import { AstraForgeAES } from './encryption';
import { z } from 'zod';

// ... existing code ...

// Add AES decryption for secrets
private static aes: AstraForgeAES | null = null;

private static async initAES(): Promise<void> {
  if (this.aes) return;
  // Load master secret from secure location or fallback/generate
  const masterSecretPath = process.env.ASTRAFORGE_MASTER_SECRET_PATH || path.join(__dirname, '../../../secrets/master.key');
  let masterSecret: string;
  if (fs.existsSync(masterSecretPath)) {
    masterSecret = fs.readFileSync(masterSecretPath, 'utf8').trim();
  } else {
    // Fallback or generate (securely store)
    masterSecret = 'fallback_32_char_master_secret_2025'; // Replace in prod
    fs.writeFileSync(masterSecretPath, masterSecret);
    fs.chmodSync(masterSecretPath, 0o600); // Secure perms
  }
  this.aes = new AstraForgeAES(masterSecret);
}

public static async loadSecrets(): Promise<void> {
  await this.initAES();

  const secretsPath = process.env.ASTRAFORGE_SECRETS_PATH || path.join(__dirname, '../../../secrets/encrypted.env');
  if (!fs.existsSync(secretsPath)) {
    console.warn('Encrypted secrets not found, using plain env fallback');
    this.loadPlainEnv();
    return;
  }

  try {
    const encryptedContent = fs.readFileSync(secretsPath, 'utf8');
    const plainContent = this.aes!.decrypt(encryptedContent);
    const envVars = this.loadEnvFromString(plainContent);

    // Validate with Zod schema
    const schema = z.object({
      ASTRAFORGE_API_KEY_ONE: z.string().min(1),
      ASTRAFORGE_API_KEY_TWO: z.string().min(1),
      ASTRAFORGE_API_KEY_THREE: z.string().min(1),
      ASTRAFORGE_API_KEY_FOUR: z.string().min(1),
      ASTRAFORGE_API_KEY_FIVE: z.string().min(1),
      GITHUB_TOKEN: z.string().min(1),
      // Add other env vars
    });

    const validated = schema.safeParse(envVars);
    if (!validated.success) {
      console.error('Validation errors:', validated.error.errors);
      throw new Error('Secrets validation failed');
    }

    Object.assign(process.env, validated.data);
    console.log('Secrets loaded and validated (masked in logs)');
  } catch (error) {
    console.error('Failed to load encrypted secrets:', error);
    this.loadPlainEnv(); // Fallback to .env
  }
}

private static loadPlainEnv(): void {
  // Existing fallback logic
  const dotenvPath = path.join(__dirname, '../../.env');
  require('dotenv').config({ path: dotenvPath });
  // ... validation ...
}

// For masked logging, encrypt logs before output
public static encryptLog(message: string): string {
  if (!this.aes) await this.initAES();
  return this.aes.encrypt(message);
}
EOF && npm i crypto-js --save && npm i @types/crypto-js --save-dev
cd /root/AstraForge && npm i crypto-js --legacy-peer-deps --save && npm i @types/crypto-js --legacy-peer-deps --save-dev && npm ls crypto-js @types/crypto-js
