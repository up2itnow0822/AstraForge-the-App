import { defineAgentNexusBuildPromptRegressionSuite } from '../shared/agentNexusBuildPromptSuite';

defineAgentNexusBuildPromptRegressionSuite({
  suiteName: 'AgentNexus build prompt runner (smoke)',
});
