
## Quarterly Audit
Run node scripts/quarterly-docs.js; review lint, ADRs, OpenAPI changes; PR for updates.
